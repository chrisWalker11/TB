import time
import pyautogui
import random
c = 1
N = 101
while c <= N:
    value = random.randint(1, 1000000)

    if value % 2 == 0:
        c = c + 1

      
        
        time.sleep(random.randint(5, 90))
        pyautogui.click(pyautogui.locateOnScreen("like.png")) #click like
    else:

       
        time.sleep(random.randint(5, 80))
        pyautogui.click(pyautogui.locateOnScreen("dislike.png"))
