import time
import pyautogui
import random

while (1 == 1):
    value = random.randint(1, 1000000)

    if value % 2 == 0:

      
        
        time.sleep(random.randint(5, 90))
        pyautogui.click(pyautogui.locateOnScreen("like.png")) #click like
    else:

       
        time.sleep(random.randint(5, 80))
        pyautogui.click(pyautogui.locateOnScreen("dislike.png"))